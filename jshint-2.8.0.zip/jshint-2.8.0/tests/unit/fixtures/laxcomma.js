var a = 1
  , b = 2
  , c = 3;

function func() {
  var x, y
    , z;

  return x
  && z;
}

function test() {
    return someLongStatement === someOtherLongStatement
        ? this.someNonTrivialLengthThing(someVar, someOtherVar)
        : this.someOtherNonTrivialLengthThing(someVar, someOtherVar);
}
