function test(b) {
  var a = b = 1;
}

test();
