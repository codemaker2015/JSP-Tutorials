function bar() {
javascript: for(;;) {
        if (1==2) {
            break javascript;
        }
        break;
    }
xyz: for(;;) {
        break xyz;
    }
}
