function foo() {
    open()
    read();
    [1, 2, 3].forEach(function(i) { print(i) });
    close()
}
