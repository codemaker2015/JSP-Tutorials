export default function Header() {}

Object.defineProperty(Header, "CONST", {
  value: 1
});
