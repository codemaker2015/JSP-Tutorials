function callee() {
    return arguments.callee;
}

function caller() {
    return arguments.caller;
}