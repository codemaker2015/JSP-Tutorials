var s;
var iterator;

while (s = iterator.next()) { // jshint ignore:line

}

var u; // jshint ignore:line
b = 1; // jshint ignore:line
