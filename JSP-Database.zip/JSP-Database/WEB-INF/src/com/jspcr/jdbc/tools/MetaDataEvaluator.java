/**
*  Copyright (c) 2002 by Phil Hanna
*  All rights reserved.
*  
*  You may study, use, modify, and distribute this
*  software for any purpose provided that this
*  copyright notice appears in all copies.
*  
*  This software is provided without warranty
*  either expressed or implied.
*/
package com.jspcr.jdbc.tools;

import java.lang.reflect.*;
import java.util.*;

/**
* Evaluates the simple accessor methods of an object
*/
public class MetaDataEvaluator
{
   private Object obj;
   private Map methodMap = new TreeMap();
   private Object[] NO_PARMS = new Object[0];

   /**
   * Creates a new <code>MetaDataEvaluator</code>
   * for the specified object
   * @param obj the object
   */
   public MetaDataEvaluator(Object obj)
   {
      this.obj = obj;
      Class cls = obj.getClass();
      Method[] methods = cls.getMethods();
      for (int i = 0; i < methods.length; i++) {
         Method method = methods[i];
         if (method.getParameterTypes().length == 0) {
            Class returnType = method.getReturnType();
            if (
               returnType.equals(String.class) ||
               returnType.equals(Boolean.TYPE) ||
               returnType.equals(Integer.TYPE)
               )
            {
               methodMap.put(method.getName(), method);
            }
         }
      }
   }

   /**
   * Returns an iterator over the set of method names
   */
   public Iterator getMethodNames()
   {
      return methodMap.keySet().iterator();
   }

   /**
   * Returns the value of the specified method
   * when evaluated on the object. For simplicity,
   * no exception reporting is done.
   * @param name the method name
   */
   public Object getMethodValue(String name)
   {
      Object value = null;
      Method method = (Method) methodMap.get(name);
      if (method != null) {
         try {
            value = method.invoke(obj, NO_PARMS);
         }
         catch (Throwable ignore) {}
      }
      return value;
   }
}
