SELECT   description
FROM     products
WHERE    description LIKE "Vivaldi% in C minor%" ;

DELETE
FROM     products
WHERE    itemcode = 'bogus' ;

