/**
*  Copyright (c) 2002 by Phil Hanna
*  All rights reserved.
*  
*  You may study, use, modify, and distribute this
*  software for any purpose provided that this
*  copyright notice appears in all copies.
*  
*  This software is provided without warranty
*  either expressed or implied.
*/
package com.jspcr.forward;

/**
* A structure representing a USDA food group
* code and description.
*/
public class FoodGroup
{
   private String code;
   private String description;

   /**
   * Creates a new <code>FoodGroup</code> object.
   */
   public FoodGroup(String code, String description)
   {
      this.code = code;
      this.description = description;
   }

   /**
   * Returns the code.
   */
   public String getCode()
   {
      return code;
   }

   /**
   * Sets the code.
   * @param code the code.
   */
   public void setCode(String code)
   {
      this.code = code;
   }

   /**
   * Returns the description.
   */
   public String getDescription()
   {
      return description;
   }

   /**
   * Sets the description.
   * @param description the description.
   */
   public void setDescription(String description)
   {
      this.description = description;
   }
}
