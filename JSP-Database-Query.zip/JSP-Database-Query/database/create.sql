CREATE DATABASE IF NOT EXISTS IceCream;
USE IceCream;

DROP TABLE IF EXISTS flavors;
CREATE TABLE flavors (
   rank     INTEGER,
   name     CHAR(20)
);

INSERT INTO flavors VALUES(1,'Espresso Chip');
INSERT INTO flavors VALUES(2,'Orange Cream');
INSERT INTO flavors VALUES(3,'Peanut Butter');
INSERT INTO flavors VALUES(4,'Chocolate');
INSERT INTO flavors VALUES(5,'Strawberry');
INSERT INTO flavors VALUES(6,'Vanilla');
INSERT INTO flavors VALUES(7,'Spinach');
